<?php

return [
    'Zend\Session',
    'Zend\Form',
    'Zend\InputFilter',
    'Zend\Filter',
    'Zend\Hydrator',
    'Zend\Db',
    'Zend\Router',
    'Zend\Validator',
    //'Zend\Cache',
    //'Zend\I18n',
    'Zend\Router',
    'Zend\Validator',
    'Application',
    'Wallet',
    'Exchange',
    'Auth',
    'Staticmanager',
    //'Play',
    //'Network',
    //'Getstarted',
    //'Api',
    
];
