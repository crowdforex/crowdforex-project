## Table of Contents

- [Introduction](#introduction)
- [Features](#features)
- [Feedback](#getting-involved)
- [Mission](#mission)
- [Installation](#installation)
- [Sponsors](#donate)

## Introduction

Crowd Forex is a open source platform of cryptocurrencies trade forex, that intermediate operations of orders of trade with users

### Mission

Our mission is to develop a forex trading platform with open source crypto-currencies and implement crowdfunding of long-term investment through quota sales, and in the future to share profits from the platform with investors on a monthly basis, giving financial returns to all investors.
Our goal is the sale of 500 shares of $1,000.00, to that end, will be launched online for trading operations with crypto-currencies, and, with the profit of platform fees, will be divided proportionally to users who have acquired certain monthly
And create a distributed open-source platform to all users host and work with the support of community

### Features

* Designed as a high performance crypto-currency forex broker.
* Usability and scalability.
*  Supports multiple digital currencies (eg. Bitcoin, Litecoin, Dogecoin etc.).
* � Powerful admin dashboard and management tools.
* Highly configurable and extendable.
* Industry standard security out of the box.
* Active community behind.

## Release History

* 0.001
    * CHANGE: Update docs (module code remains unchanged)


### Requirements

Crowd Forex is development in zend framework with zend-skeleton in PHP 7.1 and MYSQL 6.0

* Linux OR Windows
* Git 1.7.10+
* Mysql
* Phpmyadmin
* Apache2
* PHP

** More details are in the [doc](doc).

### Getting started

* [Setup on Mac OS X](doc/setup-local-osx.md)
* [Setup on Ubuntu](doc/setup-local-ubuntu.md)
* [Deploy production server](doc/deploy-production-server.md)

## Installation

* <p>Sign up with <a target="_blank" href="https://m.do.co/c/397fb2277475">Digital Ocean</a><img width="1" height="1" border="0" alt="" style="border:none !important; margin:0px !important;" /></p>
* Install LAMP https://www.digitalocean.com/community/tutorials/how-to-install-linux-apache-mysql-php-lamp-stack-on-ubuntu-16-04 or Wamp http://wampserver.aviatechno.net
* Active the bcmatch to use of the bitcoin algoritm
* Access PhpMyAdmin and create the table `crowdforex` and import the sql file crowdforex to create the tables


### Clone

- Clone this repo to your local machine using `sudo git clone https://github.com/crowdforex/crowdforex-project`

## Getting Involved

Want to report a bug, request a feature, contribute or translate Crowd Forex?


### Step 1

- **Option 1**
    - Fork & star this repo!

- **Option 2**
    - Clone this repo to your local machine using `https://github.com/crowdforex/crowdforex-project.git`

- **Option 3**
    - Browse our [issues](https://github.com/crowdforex/crowdforex-project/issues), comment on proposals, report bugs.


### Step 2

- Create a new pull request using <a href="https://github.com/crowdforex/crowdforex-project/compare/" target="_blank">`https://github.com/crowdforex/crowdforex-project/compare/`</a>.

### Step 3

- **Option 1**
    - Anything you want to tell us please send it to: [crowdforex@gmail.com](mailto:crowdforex@gmail.com)
    
- **Option 2**
    - If you need technical support or customization service, contact us: [crowdforex@gmail.com](mailto:crowdforex@gmail.com)

- **Option 3**
    - Follow on social media:
        Twitter: https://twitter.com/crowd_forex
        
##Basic Work

Your use is simple, the member need buy the balance to after begin the negotiation, to this, just you create a sell order of the crypto-currencie that you have and wait a user buy depositing on your wallet (Bitcoin, Ethereum, Litecoin, ... or to up Bank Account) and after confirmed, you will available the balance on member account, with balance on account, the member can execute forex and withdraws.


## Donation

- To contribute, you can sign to community and help development the system with translate, web-development front-end and back-end and more.

Help this project send bitcoins to address:
    
    1Br3pYZxN7ASd98yyKg6syBRa2oiH8Z7pY